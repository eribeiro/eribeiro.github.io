
const state = {
  data:null, view:"papers", areas:new Set(), search:"",
  year:"", decade:"", era:"", lineage:"", venue:"", difficulty:"", tag:"",
  grouping:"year"
};
const $ = id => document.getElementById(id);
const norm = v => (v ?? "").toString().normalize("NFD").replace(/\p{Diacritic}/gu,"").toLowerCase();

async function loadYaml(path) {
  const r = await fetch(path);
  if (!r.ok) throw new Error(`Falha ao carregar ${path}: ${r.status}`);
  return jsyaml.load(await r.text());
}
async function init() {
  try {
    const [pd,rd,vd] = await Promise.all([loadYaml("papers.yaml"),loadYaml("researchers.yaml"),loadYaml("venues.yaml")]);
    state.data={papers:pd.papers,lineages:pd.lineages,metadata:pd.metadata,researchers:rd.researchers,venues:vd.venues};
    wire(); populate(); render();
  } catch(e) {
    $("results").innerHTML=`<div class="empty"><strong>Não foi possível carregar os YAMLs.</strong><br>${esc(e.message)}<br><br>Sirva a pasta por HTTP (ex.: python3 -m http.server), não via file://.</div>`;
    $("resultCount").textContent="Erro";
  }
}
function wire() {
  $("search").addEventListener("input", e=>{state.search=e.target.value;render();});
  for (const id of ["year","decade","era","lineage","venue","difficulty","tag","grouping"])
    $(id).addEventListener("change",e=>{state[id]=e.target.value;render();});
  document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>{
    state.view=b.dataset.view; document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b)); render();
  }));
  $("clearFilters").addEventListener("click", clearFilters);
}
function populate() {
  const areas=state.data.metadata.fixed_areas;
  $("areaFilters").innerHTML=areas.map(a=>`<button class="chip" data-area="${esc(a)}">${esc(a)}</button>`).join("");
  document.querySelectorAll("[data-area]").forEach(b=>b.addEventListener("click",()=>{
    const a=b.dataset.area; state.areas.has(a)?state.areas.delete(a):state.areas.add(a);
    b.classList.toggle("active",state.areas.has(a)); render();
  }));
  fill("year",[...new Set(state.data.papers.map(p=>p.year))].sort((a,b)=>b-a),x=>x);
  fill("decade",[...new Set(state.data.papers.map(p=>p.decade))].sort().reverse(),x=>x);
  fill("era",[...new Set(state.data.papers.map(p=>p.era))],human);
  fill("lineage",Object.keys(state.data.lineages).sort(),human);
  fill("venue",[...new Set(state.data.papers.map(p=>p.venue))].sort(),x=>x);
  fill("tag",[...new Set(state.data.papers.flatMap(p=>p.tags||[]))].sort((a,b)=>a.localeCompare(b)),x=>x);
}
function fill(id,values,label) {
  const s=$(id), first=s.options[0].outerHTML;
  s.innerHTML=first+values.map(v=>`<option value="${esc(v)}">${esc(label(v))}</option>`).join("");
}
function clearFilters() {
  state.areas.clear(); state.search=state.year=state.decade=state.era=state.lineage=state.venue=state.difficulty=state.tag="";
  state.grouping="year"; $("search").value=""; $("grouping").value="year";
  for(const id of ["year","decade","era","lineage","venue","difficulty","tag"]) $(id).value="";
  document.querySelectorAll(".chip").forEach(c=>c.classList.remove("active")); render();
}
function matchPaper(p) {
  if(state.areas.size && ![...state.areas].every(a=>(p.areas||[]).includes(a))) return false;
  if(state.year && String(p.year)!==state.year) return false;
  if(state.decade && p.decade!==state.decade) return false;
  if(state.era && p.era!==state.era) return false;
  if(state.lineage && !(p.lineages||[]).includes(state.lineage)) return false;
  if(state.venue && p.venue!==state.venue) return false;
  if(state.difficulty && p.difficulty!==state.difficulty) return false;
  if(state.tag && !(p.tags||[]).includes(state.tag)) return false;
  if(state.search) {
    const hay=norm([p.title,p.year,p.venue,...(p.authors||[]),...(p.tags||[]),...(p.areas||[]),...(p.lineages||[]),p.why_read].join(" "));
    if(!hay.includes(norm(state.search))) return false;
  }
  return true;
}
function render() {
  if(!state.data) return;
  ({papers:renderPapers,researchers:renderResearchers,venues:renderVenues,lineages:renderLineages}[state.view])();
  active();
}
function renderPapers() {
  const items=state.data.papers.filter(matchPaper).sort((a,b)=>b.year-a.year||a.title.localeCompare(b.title));
  $("resultCount").textContent=`${items.length} papers`;
  if(!items.length){$("results").innerHTML=empty();return;}
  if(state.grouping==="none") {$("results").innerHTML=items.map(card).join("");return;}
  const key=state.grouping;
  const groups=Map.groupBy ? Map.groupBy(items,p=>p[key]) : items.reduce((m,p)=>((m[p[key]]??=[]).push(p),m),{});
  const entries=groups instanceof Map?[...groups.entries()]:Object.entries(groups);
  entries.sort((a,b)=>key==="year"?Number(b[0])-Number(a[0]):String(b[0]).localeCompare(String(a[0])));
  $("results").innerHTML=entries.map(([g,ps])=>`<section class="year-group"><h2 class="year-heading">${esc(g)}</h2>${ps.map(card).join("")}</section>`).join("");
}
function card(p) {
  const link=p.links?.paper?`<a href="${esc(p.links.paper)}" target="_blank" rel="noopener">paper ↗</a>`:"";
  return `<article class="card">
    <h2>${esc(p.title)}</h2>
    <div class="meta">${p.year} · ${esc(p.venue)} · ${esc((p.authors||[]).join(", "))}</div>
    <div class="badges">${(p.areas||[]).map(badge).join("")}${(p.tags||[]).map(badge).join("")}${badge(p.decade)}${badge(p.difficulty)}${badge(`${p.reading_time_minutes} min`)}</div>
    <p>${esc(p.why_read||"")}</p>
    ${(p.lineages||[]).length?`<div class="meta">Trilhas: ${(p.lineages||[]).map(human).join(" · ")}</div>`:""}
    ${link}
  </article>`;
}
function renderResearchers() {
  let xs=state.data.researchers;
  if(state.areas.size) xs=xs.filter(r=>[...state.areas].every(a=>(r.areas||[]).includes(a)));
  if(state.search) xs=xs.filter(r=>norm([r.name,...(r.areas||[]),...(r.topics||[])].join(" ")).includes(norm(state.search)));
  xs=xs.sort((a,b)=>a.name.localeCompare(b.name)); $("resultCount").textContent=`${xs.length} pesquisadores`;
  $("results").innerHTML=xs.length?xs.map(r=>`<article class="card"><h2>${esc(r.name)}</h2><div class="badges">${(r.areas||[]).map(badge).join("")}</div><p>${esc((r.topics||[]).join(" · "))}</p><div class="meta">${(r.paper_ids||[]).length} papers relacionados</div></article>`).join(""):empty();
}
function renderVenues() {
  let xs=state.data.venues;
  if(state.areas.size) xs=xs.filter(v=>[...state.areas].every(a=>(v.areas||[]).includes(a)));
  if(state.search) xs=xs.filter(v=>norm([v.name,v.organization,v.tier,...(v.areas||[])].join(" ")).includes(norm(state.search)));
  xs=xs.sort((a,b)=>a.name.localeCompare(b.name)); $("resultCount").textContent=`${xs.length} venues`;
  $("results").innerHTML=xs.length?xs.map(v=>`<article class="card"><h2>${esc(v.name)}</h2><div class="meta">${esc(v.organization)} · ${esc(v.tier)}</div><div class="badges">${(v.areas||[]).map(badge).join("")}</div></article>`).join(""):empty();
}
function renderLineages() {
  let es=Object.entries(state.data.lineages);
  if(state.lineage) es=es.filter(([n])=>n===state.lineage);
  if(state.search) es=es.filter(([n,ids])=>norm([n,...ids.map(id=>state.data.papers.find(p=>p.id===id)?.title||"")].join(" ")).includes(norm(state.search)));
  $("resultCount").textContent=`${es.length} trilhas`;
  $("results").innerHTML=es.length?es.sort((a,b)=>a[0].localeCompare(b[0])).map(([n,ids])=>{
    const ps=ids.map(id=>state.data.papers.find(p=>p.id===id)).filter(Boolean);
    return `<article class="card"><h2>${esc(human(n))}</h2><div class="lineage-flow">${ps.map((p,i)=>`${i?'<span class="arrow">→</span>':''}<span class="lineage-step">${p.year} · ${esc(p.title)}</span>`).join("")}</div></article>`;
  }).join(""):empty();
}
function active() {
  const ps=[];
  if(state.areas.size) ps.push([...state.areas].join(" + "));
  for(const k of ["year","decade","era","lineage","venue","difficulty","tag"]) if(state[k]) ps.push(k==="era"||k==="lineage"?human(state[k]):state[k]);
  if(state.search) ps.push(`“${state.search}”`);
  $("activeSummary").textContent=ps.length?`· ${ps.join(" · ")}`:"";
}
function human(s){return String(s).replaceAll("-"," ").replace(/\b\w/g,c=>c.toUpperCase());}
function badge(s){return `<span class="badge">${esc(s)}</span>`;}
function empty(){return `<div class="empty">Nenhum resultado para os filtros atuais.</div>`;}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
init();
